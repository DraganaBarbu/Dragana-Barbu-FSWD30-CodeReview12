<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CARS
 */

?>

	</div><!-- #content -->

	<footer class="blog-footer text-center jumbotron">
		<div class="row">
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
				<h3 class="text-center">Facebook</h3>
				<img src="http://webiconspng.com/wp-content/uploads/2017/09/Facebook-PNG-Image-63654.png" width="80">
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
				<h3 class="text-center">Instagram</h3>
				<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/Instagram.pn.png/240px-Instagram.pn.png" width="80">
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
				<h3 class="text-center">GitHub</h3>
				<img src="http://sanyangfrp.com/data/out/580/500030324-github-png-transparent-images.png" width="80">
			</div>
			<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
				<h3 class="text-center">Twitter</h3>
				<img src="http://pngimg.com/uploads/twitter/twitter_PNG1.png" width="80">
			</div>
		</div>
		<br>
     	<h4> &copy; <?php echo Date('Y'); ?> - <?php bloginfo('name'); ?></h4>
     	<h4>
       		<a href="#">Back to top</a>
     	</h4>
   </footer>
   <?php wp_footer(); ?>
</div><!-- #page -->

<?php wp_footer(); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$(".thumbnail").on("mouseover",function(){
			$(this).css("box-shadow","3px 3px 20px black");
		});
		$(".thumbnail").on("mouseout",function(){
			$(this).css("box-shadow","");
		})
	})
</script>
</body>
</html>